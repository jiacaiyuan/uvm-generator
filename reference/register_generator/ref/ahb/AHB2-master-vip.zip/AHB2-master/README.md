# AHB2
AMBA AHB 2.0 VIP in SystemVerilog UVM
