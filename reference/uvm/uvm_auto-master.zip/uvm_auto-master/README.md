# uvm_auto
uvm auto generator

## Install
- python3
  - mako
  - json

## Usage
```sh
cd uvm_agent_autogen
python3 agent_gen.py
```

## Issue Report
